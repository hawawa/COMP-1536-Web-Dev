<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Cash Calculator</title>
        <link rel="stylesheet" href="style/coincount.css" type="text/css" />
        <meta charset="utf-8" />
    </head>
    <body>
        <header class="content">
            <h2>Cash Calculator</h2>
            <span class="cent">&cent;&cent;&cent;&cent;</span>
            <span class="and">&amp;</span>&nbsp;
            <span class="dollar">$$$$</span>&nbsp;
            <br />
        </header>
