<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <title>Toon World</title> 
    <meta charset="utf-8"> 
</head> 
<body> 
   <dir>
      <h2>Toon World</h2>
   </dir>
</body> 
</html>